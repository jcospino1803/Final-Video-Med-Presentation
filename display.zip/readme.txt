1.Wire jumper cables of the CTE Shield to DB0-DB7

2.Put the UTFT folder into the IDE1.5.6 libraries folder. Then run IDE. 
Open the File /Examples/UTFT/Arduino��AVR��/UTFT_Textrotation_Demo.ino .  Download the ino file into the UNO ,Then reset the board  The graphics could be seen then.
